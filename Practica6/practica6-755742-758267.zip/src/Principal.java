public class Principal {

    public static void main(String[] args) {
        // Ejercicio 1
        Ejercicio1.ejercicio1();

        // Ejercicio 2
        Ejercicio2.ejercicio2();

        // Ejercicio 3
        Ejercicio3.ejercicio3();
    }
}
